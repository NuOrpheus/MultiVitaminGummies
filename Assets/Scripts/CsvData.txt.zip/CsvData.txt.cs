using UnityEngine;
using CsvHelper;
// tutorial https://joshclose.github.io/CsvHelper/getting-started/
public class CsvFields// : MonoBehaviour // probably doesnt need monobehavoir features
{
    public string enter {get; set;}
    public string start {get; set;}
    public string speaker {get; set;}
    public string dialogue {get; set;}
    public string choice {get; set;}
    public string flag {get; set;}
    public string next {get; set;}
    public string exit {get; set;}
}
/*
public class csvData : MonoBehaviour {
    public void pullCsvData(int row) {
        CsvFields data1 = new CsvFields;
        data1.enter = "testA";
        data1.start = "true";
        data1.speaker = "?";
        //data.dialogue = ["1 + [] = ?", "why are you asking this?"];
    }
} 
*/